import ReactDOM from "react-dom";
import App from "./App";
import HomePage from "./HomePage";

ReactDOM.render(<HomePage />, document.getElementById("root"));

import React, { useState } from "react";
//import Button from "react-bootstrap/Button";

import styles from "./app.module.css";

import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from "@material-ui/core";
import { Button } from "react-bootstrap";

const App = () => {
  // save clicks of each button to its own state
  const [data, setData] = useState([
    {
      title: "Anxiety",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "fear",
        "rapid heartbeat",
        "Social withdrawal",
        "panic",
        "difficulties breathing",
      ],
    },

    {
      title: "Oppositional Defiant",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Easily irritated",
        "Low self-esteem",
        "defy others",
        "blame others",
      ],
    },

    {
      title: "Conduct Disorder",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Easily irritated", "defy others", "criminal behavior"],
    },

    {
      title: "Attention Deficit Hyperactivity",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Easily irritated",
        "Difficulty concentrating",
        "restlessness",
        "fidgeting",
      ],
    },

    {
      title: "Bipolar disorder – Mania",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Easily irritated", "no sleep", "energetic"],
    },

    {
      title: "Bipolar disorder – Depression",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Low self-esteem",
        "Social withdrawal",
        "Difficulty concentrating",
        "Intrusive thoughts",
      ],
    },

    {
      title: "Bipolar disorder – Psychosis",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Easily irritated", "no sleep", "energetic"],
    },

    {
      title: "Depression",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Fatigue",
        "Low self-esteem",
        "Social withdrawal",
        "Difficulty concentrating",
        "Intrusive thoughts",
        "tired",
      ],
    },
    {
      title: "Dissociation and Dissociative Disorders",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Social withdrawal",
        "Difficulty concentrating",
        "derealisation",
        "mood shifts",
      ],
    },

    {
      title: "Eating disorders",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Weight fluctuation", "Fainting", "decreased interest in food"],
    },

    {
      title: "Symptoms of OCD – Obsessions",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["fear", "Intrusive thoughts", "Fear of germs"],
    },

    {
      title: "Symptoms of OCD – Compulsions",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "Social withdrawal",
        "Easily irritated",
        "Intrusive thoughts",
        "Excessive cleaning",
        "Paranoia",
      ],
    },

    {
      title: "Post-traumatic Stress Disorder",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: [
        "fear",
        "rapid heartbeat",
        "Intrusive thoughts",
        "Unwanted memories",
      ],
    },

    {
      title: "Psychosis",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Hallucinations", "Confused thinking"],
    },

    {
      title: "Schizophrenia",
      summary:
        "summary summary summary summary summary summary summary summary ",
      link: "http://google.com/",
      tags: ["Hallucinations", "Social withdrawal"],
    },
  ]);

  const tagList = data.reduce((tagList, item) => {
    let newTags = item.tags.filter((j) => tagList.indexOf(j) === -1);
    return [...tagList, ...newTags];
  }, []);

  const [stateTagList, setStateTagList] = useState([]);

  const RemoveOrAddTags = (tag) => {
    if (stateTagList.includes(tag)) {
      return stateTagList.filter((i) => i !== tag);
    } else {
      return [...stateTagList, tag];
    }
  };

  const [stateTagColor, setStateTagColor] = useState(
    Array(tagList.length).fill("aquamarine")
  );

  const TagButton = ({ tag, index }) => {
    return (
      <Button
        className={styles.margind}
        style={{ backgroundColor: stateTagColor[index] }}
        onClick={() => {
          setStateTagList(() => RemoveOrAddTags(tag));
          setData(data);
          let tempTagColor = stateTagColor;

          if (tempTagColor[index] === "aquamarine") {
            tempTagColor[index] = "red";
          } else {
            tempTagColor[index] = "aquamarine";
          }
          setStateTagColor(tempTagColor);
        }}
      >
        {tag}
      </Button>
    );
  };

  function getArraysIntersection(a1, a2) {
    return a1.filter(function (n) {
      return a2.indexOf(n) !== -1;
    });
  }

  return (
    <div className="container" style={{ marginTop: "90px" }}>
      <div className="row">
        <div className="border border-dark border-2 rounded-3">
          <div className="container">
            <div className={styles.tags}>
              {tagList.map((item, i) => (
                <TagButton key={i} tag={item} index={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <div className="border border-dark border-2 rounded-3">
          <div className="container" style={{ columnCount: 3 }}>
            <div className="container">
              {data
                .filter(
                  (item) =>
                    getArraysIntersection(item.tags, stateTagList).length > 0
                )
                .map((item, i) => (
                  <DisorderCard
                    key={i}
                    title={item.title}
                    content={item.summary}
                    link={item.link}
                  ></DisorderCard>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const DisorderCard = ({ title, content, link }) => {
  return (
    <Card className={useStyles().root}>
      <Link className="btn btn-info" href={link} underline="none">
        <CardActionArea>
          <CardContent>
            <Typography gutterBottom variant="h5" component="h2">
              {title}{" "}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p">
              {content}
            </Typography>
          </CardContent>
        </CardActionArea>
      </Link>
    </Card>
  );
};

const useStyles = makeStyles({
  root: {
    className: "btn-warning",
    backgroundColor: 0,
    maxWidth: 310,
    margin: 10,
    padding: 0,
    minWidth: 100,
    transition: "transform 0.15s ease-in-out",
    "&:hover": { transform: "scale3d(1.05, 1.05, 1)" },
  },
});

export default App;

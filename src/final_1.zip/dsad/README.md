# Hackathon UCI 2022 (Feb 25 - Feb 26)

- 36 hours
- no topic

## team members

- Orhan Ozbasaran
- Tracy Trinh
- Helen Pham
- James Nguyen
